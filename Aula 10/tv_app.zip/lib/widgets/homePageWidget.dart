import "package:flutter/material.dart";

class HomePageWidget extends StatelessWidget {
  const HomePageWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      Image.asset(
        "assets/background.jpeg",
        height: double.infinity,
        width: double.infinity,
        fit: BoxFit.cover,
      ),
      Center(
          child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text("Página inicial"),
          SizedBox(
            height: 30,
          ),
          Text("App de TV")
        ],
      )),
    ]);
  }
}
