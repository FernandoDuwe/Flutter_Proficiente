import "dart:async";

import "package:flutter/material.dart";

class BottomNavigator extends StatefulWidget {
  PageController pageController;
  double lastPage = 0;

  BottomNavigator(
      {required this.pageController, required this.lastPage, super.key});

  @override
  State<BottomNavigator> createState() => _BottomNavigatorState();
}

class _BottomNavigatorState extends State<BottomNavigator> {
  bool isAutoChanging = false;
  Timer? currentTimer;

  bool get hasNextPage {
    if (widget.pageController.page == null) return true;

    return widget.pageController.page! < widget.pageController.offset;
  }

  bool get hasPreviousPage {
    if (widget.pageController.page == null) return true;

    return widget.pageController.page! > widget.pageController.initialPage;
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery
        .of(context)
        .size;

    return Opacity(
      opacity: 0.5,
      child: Container(
        alignment: Alignment.center,
        height: 50,
        width: size.width,
        child: Container(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              ElevatedButton(
                  onPressed: this.hasPreviousPage
                      ? () {
                    widget.pageController.previousPage(
                        duration: Duration(seconds: 1),
                        curve: Curves.ease);

                    setState(() {});
                  }
                      : null,
                  child: Icon(Icons.skip_previous)),
              ElevatedButton(
                  onPressed: () {
                    setState(() {
                      this.isAutoChanging = !this.isAutoChanging;
                    });

                    if (this.isAutoChanging) {
                      this.currentTimer = Timer.periodic(
                        Duration(seconds: 3),
                            (timer) {
                          if (widget.lastPage == widget.pageController.page!) {
                            widget.pageController.animateToPage(widget
                                .pageController.initialPage,
                                duration: Duration(milliseconds: 300),
                                curve: Curves.ease);
                            return;
                          }

                          widget.pageController.nextPage(
                              duration: Duration(seconds: 1),
                              curve: Curves.ease);
                        },
                      );
                    } else {
                      currentTimer!.cancel();
                    }
                  },
                  child: Icon(
                      this.isAutoChanging ? Icons.pause : Icons.play_arrow)),
              ElevatedButton(
                  onPressed: this.hasNextPage
                      ? () {
                    widget.pageController.nextPage(
                        duration: Duration(seconds: 1),
                        curve: Curves.ease);

                    setState(() {});
                  }
                      : null,
                  child: Icon(Icons.skip_next))
            ],
          ),
        ),
      ),
    );
  }
}
