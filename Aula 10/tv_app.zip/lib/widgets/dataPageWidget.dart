import "package:flutter/material.dart";

class DataPageWidget extends StatelessWidget {
  final String title;
  final String subTitle;
  final List<Color> colors;
  final int data;

  const DataPageWidget(
      {required this.title,
      required this.subTitle,
      required this.colors,
      required this.data,
      super.key});

  Icon _getIcon() {
    if (this.data < 25)
      return Icon(Icons.cloud, color: Colors.white, size: 64);

    return Icon(Icons.sunny, color: Colors.yellowAccent, size: 64);
  }

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      Container(
        padding: EdgeInsets.all(30),
        width: double.infinity,
        height: double.infinity,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              this.title,
              style: TextStyle(fontSize: 34, color: Colors.white),
            ),
            Text(this.subTitle, style: TextStyle(fontSize: 24, color: Colors.white),),
          ],
        ),
        decoration:
            BoxDecoration(gradient: LinearGradient(colors: this.colors)),
      ),
      Positioned(
        bottom: 30,
        right: 30,
        child: Text(
          this.data.toString() + "º",
          style: TextStyle(fontSize: 128, fontWeight: FontWeight.bold, color: Colors.white),
        ),
      ),
      Positioned(
          top: 30,
          right: 30,
          child: _getIcon())
    ]);
  }
}
