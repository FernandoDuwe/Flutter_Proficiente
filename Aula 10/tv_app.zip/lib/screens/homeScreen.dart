import "package:flutter/material.dart";
import "package:tv_app/widgets/buttonNavigator.dart";
import "package:tv_app/widgets/dataPageWidget.dart";
import "package:tv_app/widgets/homePageWidget.dart";

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  PageController _controller = PageController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(children: [
        PageView(
          onPageChanged: (value) {
            setState(() {

            });
          },
          controller: _controller,
          children: [
            HomePageWidget(),
            DataPageWidget(
                title: "Temperatura atual",
                subTitle: "Temperatura em Blumenau/SC",
                colors: [
                  Colors.blueAccent,
                  Colors.blue,
                  Colors.lightBlueAccent
                ],
                data: 23),
            DataPageWidget(
                title: "Temperatura atual",
                subTitle: "Temperatura em São Paulo/SP",
                colors: [Colors.orange, Colors.orangeAccent],
                data: 28),
          ],
        ),
        Positioned(
            bottom: 10,
            child: BottomNavigator(
              lastPage: 2,
          pageController: _controller,
        ))
      ]),
    );
  }
}
