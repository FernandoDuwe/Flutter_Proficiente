class MenuOptionModel {
  String name = "";
  String route = "/";

  MenuOptionModel({ required this.name });
}