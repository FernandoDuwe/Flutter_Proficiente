class AppModel {
  bool showDebug = false;
  bool showDevFeatures = false;
  bool requireLogin = true;

  AppModel.asDeveloper() {
    showDebug = true;
    showDevFeatures = true;
    requireLogin = false;
  }

  AppModel.asTester() {
    showDevFeatures = true;
  }

  AppModel.asClient() {

  }
}