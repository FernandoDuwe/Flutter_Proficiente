import 'package:admin_app/mainCommon.dart';
import 'package:admin_app/models/appModel.dart';

void main() {
  mainCommon(AppModel.asTester());
}