import "package:admin_app/models/appModel.dart";
import "package:admin_app/models/menuOptionModel.dart";
import "package:admin_app/repositories/menuOptionsRepository.dart";
import "package:flutter/material.dart";
import "package:provider/provider.dart";

class MenuDrawer extends StatelessWidget {
  const MenuDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    bool showNewFeatures = Provider.of<AppModel>(context).showDevFeatures;

    return Drawer(
        child: ListView.builder(
      itemCount: MenuOptionsRepository.getOptions(showNewFeatures).length,
      itemBuilder: (context, index) {
        MenuOptionModel item =
            MenuOptionsRepository.getOptions(showNewFeatures)[index];

        return ListTile(
          title: Text(item.name),
          subtitle: Text("Rota ${item.route}"),
        );
      },
    ));
  }
}
