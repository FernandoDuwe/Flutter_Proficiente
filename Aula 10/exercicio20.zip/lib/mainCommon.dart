import "package:admin_app/models/appModel.dart";
import "package:admin_app/screens/homeScreen.dart";
import "package:admin_app/screens/loginScreen.dart";
import "package:flutter/material.dart";
import "package:provider/provider.dart";

void mainCommon(AppModel appModel) {
  runApp(Provider(create: (context) => appModel, child: MyApp()));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: Provider.of<AppModel>(context).showDebug,
      home: (Provider.of<AppModel>(context).requireLogin
          ? LoginScreen()
          : HomeScreen()),
    );
  }
}
