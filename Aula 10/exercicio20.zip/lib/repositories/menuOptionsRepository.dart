import '../models/menuOptionModel.dart';

class MenuOptionsRepository {
  static List<MenuOptionModel> getOptions(bool showNewFeatures) {
    List<MenuOptionModel> options = [
      MenuOptionModel(name: "Cadastro de usuários"),
      MenuOptionModel(name: "Cadastro de produtos"),
      MenuOptionModel(name: "Cadastro de pedidos"),
    ];

    if (showNewFeatures)
      options.add(MenuOptionModel(name: "Cadastro de clientes"));

    return options;
  }
}
