import "package:app_iw_test/widgets/routeWidget.dart";
import "package:flutter/material.dart";

class OptionDrawer extends StatelessWidget {
  const OptionDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    List<String> options = RouteWidget.of(context)!.options;

    return Drawer(
      child: ListView.builder(
        itemCount: options.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(options[index]),
          );
      },),
    );
  }
}
