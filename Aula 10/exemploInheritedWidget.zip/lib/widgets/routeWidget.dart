import "package:flutter/material.dart";

class RouteWidget extends InheritedWidget {
  List<String> options = [
    "Usuários",
    "Senhas",
    "Contas",
    "Imagens"
  ];

  RouteWidget({required super.child});

  @override
  bool updateShouldNotify(covariant InheritedWidget oldWidget) {
    return true;
  }

  static RouteWidget? of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType();
  }
}