import "dart:ffi";

import "package:app_iw_test/widgets/optionDrawer.dart";
import "package:app_iw_test/widgets/routeWidget.dart";
import "package:flutter/material.dart";

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    List<String> options = RouteWidget.of(context)!.options;

    return Scaffold(
      appBar: AppBar(
        title: Text("Página inicial"),
      ),
      drawer: OptionDrawer(),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          RouteWidget.of(context)!.options.add("Nova opção");
        },
        child: Icon(Icons.add),
      ),
      body: ListView.builder(
        itemCount: options.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(options[index]),
          );
        },
      ),
    );
  }
}
